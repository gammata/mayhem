This is a package of pixel shaders intended for old school emulators. 
Copyrights are held by the respective authors.

https://github.com/libretro/glsl-shaders


Note: Filename must end with "bilinear.glsl" to enable bilinear hardware filtering (GL_LINEAR)
